import java.util.Scanner;
public class Calculator {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String strForCalc;
		
		strForCalc = input.nextLine();
		input.close();
		
		System.out.println(strForCalc);
		
		strForCalc = RPN.format(strForCalc);
		
		RPN.calc(strForCalc);
		
		System.out.println(strForCalc);
		
	}
}

